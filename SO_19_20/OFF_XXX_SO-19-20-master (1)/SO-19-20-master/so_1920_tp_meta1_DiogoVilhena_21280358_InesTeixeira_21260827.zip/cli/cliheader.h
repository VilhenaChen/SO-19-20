#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "climsg.h"
#include <string.h>
#include "clifuncmenu.c"

void Nova_MSG();
void clean_stdin();
void Consulta_L_Topicos();
void Consulta_L_Titulos();
void Consulta_Mensagem();
void Subscrever_Canc_Subs_Topico();
