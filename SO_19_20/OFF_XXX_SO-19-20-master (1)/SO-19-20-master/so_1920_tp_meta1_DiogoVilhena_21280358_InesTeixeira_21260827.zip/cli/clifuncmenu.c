void clean_stdin()
{
    int c;
    do {
        c = getchar();
    } while (c != '\n' && c != EOF);
}

void Nova_MSG()
{
        pmsg nova_msg = NULL;
        char topic[50];
        char tit[50];
        char corp[1000];
        int dur, resposta;
        nova_msg = malloc(sizeof(msg));
        do{
                clean_stdin();
                printf("\n Insira uma nova mensagem:\n");
                printf("\nTopico da Mensagem: ");
                fgets(topic,sizeof(topic),stdin);
                printf("\nTitulo da Mensagem: ");
                fgets(tit,sizeof(tit),stdin);
                printf("\nCorpo  da Mensagem: ");
                fgets(corp,sizeof(corp),stdin);
                printf("\nDuracao da Mensagem: ");
                scanf("%d", &dur);
                printf("\nConteudo da mensagem:\n");
                printf("\nTopico: %s", topic);
                printf("\nTitulo: %s", tit);
                printf("\nCorpo: %s", corp);
                printf("\nDuracao: %d", dur);
                do{
                        printf("\nPretende enviar esta mensagem? \n 1-Sim \n 2-Nao\n");
                        scanf("%d", &resposta);
                }while(resposta < 1 || resposta > 2);
        }while(resposta == 2);
        clean_stdin();
        strcpy(nova_msg->topico,topic);
        strcpy(nova_msg->titulo,tit);
        strcpy(nova_msg->corpo,corp);
        nova_msg->duracao = dur;
        nova_msg->prox = NULL;
        printf("\nMensagem enviada!");
        free(nova_msg);
}

void Consulta_L_Topicos()
{
        printf("\n----Topicos:\n");
        printf("\n Perdidos e Achados");
        printf("\n Assuntos Financeiros");
        printf("\n Publicidade");
        printf("\n Curriculo\n");
}

void Consulta_L_Titulos()
{
        int top;
        do{
                printf("\n----Topicos:\n");
                printf("\n 1- Perdidos e Achados");
                printf("\n 2- Assuntos Financeiros");
                printf("\n 3- Publicidade");
                printf("\n 4- Curriculo\n");
                printf("\nInsira o numero correspondente ao topico do qual pretende ver os titulos:");
                scanf("%d",&top);
                switch (top)
                {
                        case 1:
                                printf("\nTopico: Perdidos e Achados\n");
                                printf("\nCachecol encontrado\nCartao de Cidadao Perdido\nCarteira encontrada\n");
                                break;
                        case 2:
                                printf("\nTopico: Assustos Financeiros\n");
                                printf("\nPagamento de Servico\nPedido de Reembolso\n");
                                break;
                        case 3:
                                printf("\nPublicidade\n");
                                printf("\nSistema de Seguranca\n");
                                break;
                        case 4:
                                printf("\nTopico: Curriculo\n");
                                printf("\nCurriculo Carolina Carvalho\nCurriculo Jose Manuel\n");
                                break;
                        default:
                                printf("\nOpcao Invalida!\n");
                };
                clean_stdin();
        }while(top < 1 || top >4);
}

void Consulta_Mensagem()
{
	int top, subopt;
        do{
                printf("\n----Topicos:\n");
                printf("\n 1- Perdidos e Achados");
                printf("\n 2- Assuntos Financeiros");
                printf("\n 3- Publicidade");
                printf("\n 4- Curriculo\n");
                printf("\nInsira o numero correspondente ao topico do qual pretende ver os titulos:");
                scanf("%d",&top);
                switch (top)
                {
                        case 1:
                                do
                                {
                                        printf("\nTopico: Perdidos e Achados\n");
                                        printf("\n1-Cachecol encontrado\n2-Cartao de Cidadao Perdido\n3-Carteira encontrada\n");
                                        printf("Insira o numero correspondente ao titulo do qual pretende ver a mensagem: ");
                                        clean_stdin();
                                        scanf("%d",&subopt); 
                                        switch(subopt)
                                        {
                                                case 1:
                                                        printf("\nFoi encontrado um cachecol beje na casa de banho feminina. Este encontra-se neste momento nos Perdidos e Achados.\n");
                                                        break;
                                                case 2:
                                                        printf("\nPerdeu se um cartao de Cidadao com o nome Fernando Pessoa algures nas instalacoes do Coimbra Shopping");
                                                        break;
                                                case 3:
                                                        printf("\nFoi encontrada uma carteira preta, da marca Lacoste na Fnac do Forum de Coimbra. Esta neste momento no balcao de informacoes.\n");
                                                        break;
                                                default:
                                                        printf("Opcao Errada!!!");
                                        };

                                }while(subopt < 1 || subopt > 3);
                                break;
                        case 2:
                                do
                                {
                                        printf("\nTopico: Assustos Financeiros\n");
                                        printf("\n1-Pagamento de Servi  o\n2-Pedido de Reembolso\n");
                                        printf("Insira o numero correspondente ao titulo do qual pretende ver a mensagem: ");
                                        clean_stdin();
                                        scanf("%d",&subopt); 
                                        switch(subopt)
                                        {
                                                case 1:
                                                        printf("\nEncontra-se diponivel a opcao para o pagameto mensal.\n");
                                                        break;
                                                case 2:
                                                        printf("\nVenho por este meio solicitar o reembolso da minha ultima encomenda no vosso website, uma vez que o material vinha defeituoso.\n");
                                                        break;
                                                default:
                                                        printf("Opcao Errada!!!");
                                        };
                                }while(subopt < 1 || subopt > 2);
                                break;
                        case 3:
                                do
                                {
                                        printf("\nPublicidade\n");
                                        printf("\n1-Sistema de Seguranca\n");
                                        printf("Insira o numero correspondente ao titulo do qual pretende ver a mensagem: ");
                                        clean_stdin();
                                        scanf("%d",&subopt); 
                                        switch(subopt)
                                        {
                                                case 1:
                                                        printf("\nProteja-se a si e a sua familia, com os alarmes prossegur! Fale ja com o seu especialista.\n");
                                                        break;
                                                default:
                                                        printf("Opcao Errada!!!");
                                        };
                                }while(subopt != 1);
                                break;

                        case 4:
                                do
                                {
                                        printf("\nTopico: Curriculo\n");
                                        printf("\n1-Curriculo Carolina Carvalho\n2-Curriculo Jose Manuel\n");
                                        printf("Insira o numero correspondente ao titulo do qual pretende ver a mensagem: ");
                                        clean_stdin();
                                        scanf("%d",&subopt);
                                        switch(subopt)
                                        {
                                                case 1:
                                                        printf("\nNome: Carolina Carvalho Idade:44 Habilitacoes Literarias: Licenciada em Engenharia Informatica\n");
                                                        break;
                                                case 2:
                                                        printf("\nNome: Jose Manuel Idade:25 Habilitacoes Literarias: 12 Ano.\n");
                                                        break;
                                                default:
                                                        printf("Opcao Errada!!!");
                                        };
                                }while(subopt < 1 || subopt > 2);

                                break;
                        default:
                                printf("\nOpcao Invalida!\n");
                };
                clean_stdin();
        }while(top < 1 || top >4);
}

void Subscrever_Canc_Subs_Topico()
{
	int op, subopt;

        do
        {
                printf("\n1- Subscrever Topicos\n");
                printf("\n2- Cancela a subscricao de Topicos\n");
                printf("Introduza uma das opcoes: ");
                clean_stdin();
                scanf("%d", &op);
                switch(op)
                {
                        case 1:
                                do
                                {
                                        printf("\nSubcricao de Topicos\n");
                                        printf("\n1- Perdido e Achados");
                                        printf("\n2- Assuntos Financeiros");
                                        printf("\n3- Publicidade");
                                        printf("\n4- Curriculo");
                                        printf("\nInsira o Topico que pretende subscrever: ");
                                        clean_stdin();
                                        scanf("%d",&subopt);
                                        switch (subopt)
                                        {
                                                case 1:
                                                        printf("O Topico <Perdidos e Achados> foi subscrito com sucesso\n");
							break;
                                                case 2:
                                                        printf("O Topico <Assuntos Financeiros> foi subscrito com sucesso\n");
							break;
                                                case 3:
                                                        printf("O Topico <Publicidade> foi subscrito com sucesso\n");
							break;
                                                case 4:
                                                        printf("O Topico <Curriculo> foi subscrito com sucesso\n");
							break;
                                                default:
                                                        printf("Opcao Invalida\n");
                                        };
                                }while(subopt < 1 || subopt > 4);
			case 2:
				do
				{
                                        printf("\n1- Perdido e Achados");
                                        printf("\n2- Assuntos Financeiros");
                                        printf("\n3- Publicidade");
                                        printf("\n4- Curriculo");
                                        printf("\nInsira o Topico que pretende cancelar a subscricao: ");
                                        clean_stdin();
                                        scanf("%d",&subopt);
                                        switch (subopt)
                                        {
                                                case 1:
                                                        printf("A Subscricao do Topico <Perdidos e Achados> foi cancelada com sucesso\n");
                                                        break;
                                                case 2:
                                                        printf("A Subscricao do Topico <Assuntos Financeiros> foi cancelada com sucesso\n");
                                                        break;
                                                case 3:
                                                        printf("A Subscricao do Topico <Publicidade> foi cancelada com sucesso\n");
                                                        break;
                                                case 4:
                                                        printf("A Subscricao do Topico <Curriculo> foi cancelada com sucesso\n");
                                                        break;
                                                default:
                                                        printf("Opcao Invalida\n");
                                        };
                                }while(subopt < 1 || subopt > 4);
			default:
				printf("Opcao Invalida\n");
                };
        }while (op < 1 || op > 2);
}

