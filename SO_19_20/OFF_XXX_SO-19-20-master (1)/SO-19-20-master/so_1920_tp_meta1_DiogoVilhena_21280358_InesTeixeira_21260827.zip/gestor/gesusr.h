typedef struct users usr, *pusr;
typedef struct top_user tu, *ptu;
struct users
{
	char nome;
	int indice;
	ptu topcs;
	pusr prox;
};

struct top_user
{
	char topico[50];
	ptu prox;
};
