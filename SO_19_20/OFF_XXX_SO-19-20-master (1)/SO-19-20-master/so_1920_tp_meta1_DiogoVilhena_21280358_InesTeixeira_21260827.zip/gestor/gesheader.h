#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include "gesmsg.h" /* header responsavel pelas listas de msg, topicos titulos */
#include "gesusr.h" /* Header Responsavel pela lista de users */
#include <sys/types.h>
#include <unistd.h>
#include "gesfuncverif.c"
#include "gescomandos.c"

#define MAXMSG 10
#define MAXCOM 30
#define N_PROIB 1
