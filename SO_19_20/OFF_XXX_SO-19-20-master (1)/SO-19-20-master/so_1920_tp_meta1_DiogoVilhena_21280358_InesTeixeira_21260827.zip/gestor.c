/* Gestor.c */

#include "gestor/gesheader.h"

int main(int argc, char** argv)
{
	char input[MAXCOM+1];
	char comando[20];
	char argumento[20];
	int verifica_comando;
	int filtro=1;
	int infp,outfp;
	char buff[128];
	char lixo;
	int n_p_encontradas;
	char forb_words[20];
	int num_proib;
	if(getenv("FICHEIROPALAVRAS") == NULL)
		strcat(forb_words,"fwords.txt");
	else
		strcat(forb_words,getenv("FICHEIROPALAVRAS"));
	if(lanca_verifica_mensagem("Verificador",forb_words,&infp,&outfp) <= 0)
	{
		printf("\nFalha em lancar o verificador!\n");
	}

	memset(buff, 0x0, sizeof(buff)); //limpa o buffer

	write(infp, "batata frita em cima da mesa com melao\n",39);
	write(infp, "##MSGEND##\n",11);

	read(outfp, buff, 128);

	if(strcmp(buff,"ERROR-1\n")==0||strcmp(buff,"ERROR-2\n")==0||strcmp(buff,"ERROR-3\n")==0)
	{
		printf("Falha ao verificar a mensagem");
	}
	else
	{
		if(sscanf(buff,"%d%c",&n_p_encontradas,&lixo) != 2)
			printf("Falha ao verificar mensagem! 2");
		else
		{
			if(getenv("MAXPROIBIDAS")==NULL)
				num_proib=N_PROIB;
			else
			{
				sscanf(getenv("MAXPROIBIDAS"),"%d",&num_proib);
			}
			if(n_p_encontradas < num_proib)
				printf("A mensagem foi aceite pelo verificador!");
			else
				printf("A mensagem nao foi aceite pelo verificador!");
		}
	}
	sleep(1);
	close(infp);
	do
	{
		verifica_comando=0;
		printf("\n Formato: comando opcoes-ou-argumentos-do-comando\n");
		printf("\n Comando ->");
		fgets(input,MAXCOM,stdin);
		if(sscanf(input,"%s %s",comando,argumento)!=2)
			argumento[0]='\0';
		verifica_comando=comandos_servidor(comando,argumento,&filtro);
		if(verifica_comando==1 && strcmp(comando,"shutdown") != 0)
		{
			printf("COMANDO INVALIDO\n Por favor insira um novo comando!");
		}
	}while(strcmp(comando,"shutdown")!=0);
	write(infp,"SIGUSR2\n",8);
	printf("\nO verificador foi desligado! O programa vai encerrar!\n");
	return 0;
}
