/* cliente.c */

#include "cli/cliheader.h"

int main(int argc, char** argv)
{
	int op=0;
	char username[16];
	printf("\nIntroduza nome de utilizador:");
	scanf("%s",username);
	fflush(stdin);
	do
	{
		printf("\nMENU\n");
		printf("\nOpcao 1 - Escrever Nova Mensagem");
		printf("\nOpcao 2 - Consultar a lista de topicos atualmente existente");
		printf("\nOpcao 3 - Consultar a lista de titulos de mensagens de um determinado topico");
		printf("\nOpcao 4 - Consultar uma mensagem de um topico");
		printf("\nOpcao 5 - Subscrever / Cancelar subscricao de um topico");
		printf("\nOpcao 6 - Exit");
		printf("\nInsira a opcao pretendida: ");
		scanf("%d",&op);
		switch (op)
		{
			case 1:
				Nova_MSG();
				break;
			case 2:
				Consulta_L_Topicos();
				break;
			case 3:
				Consulta_L_Titulos();
				break;
			case 4:
				Consulta_Mensagem();
				break;
			case 5:
				Subscrever_Canc_Subs_Topico();
				break;
			case 6:
				break;
			default:
				printf("\nOpcao Invalida!\n");
		};
	}while(op != 6);
	return 0;
}
